export default function Gallery() {
    return (
        <section>
            <div className="inner">
                <h1>Gallery</h1>
            </div>
        </section>
    )
}