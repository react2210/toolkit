export default function Member() {
    return (
        <section>
            <div className="inner">
                <h1>Member</h1>
            </div>
        </section>
    )
}