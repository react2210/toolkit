export default function Youtube() {
    return (
        <section>
            <div className="inner">
                <h1>Youtube</h1>
            </div>
        </section>
    )
}