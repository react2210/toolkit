export default function Department() {
    return (
        <section>
            <div className="inner">
                <h1>Department</h1>
            </div>
        </section>
    )
}