export default function Location() {
    return (
        <section>
            <div className="inner">
                <h1>Location</h1>
            </div>
        </section>
    )
}