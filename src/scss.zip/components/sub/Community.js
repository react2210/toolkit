export default function Community() {
    return (
        <section>
            <div className="inner">
                <h1>Community</h1>
            </div>
        </section>
    )
}