export default function Content() {
    return (
        <section>
            <div className="inner">
                <h1>Content</h1>
            </div>
        </section>
    )
}