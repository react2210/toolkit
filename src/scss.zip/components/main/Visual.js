export default function Visual() {
    return (
        <figure>
            <div className="inner">
                <h1>Visual</h1>
            </div>
        </figure>
    )
}